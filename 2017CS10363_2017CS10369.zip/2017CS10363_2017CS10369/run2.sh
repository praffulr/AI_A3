./step2 $1
