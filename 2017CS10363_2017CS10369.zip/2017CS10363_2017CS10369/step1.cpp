#include <stdio.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;
long int edgeCondition(vector<vector<short>> &e1, vector<vector<short>> & e2, ofstream * satinput, short* isIsoG1, short* isIsoG2,  vector<vector<short>> &M);
int oneOneMap(int n1, int n2, ofstream * satinput, short* isIsoG1, short* isIsoG2,  vector<vector<short>> &M);
int isolatedMap(int n1, int n2, ofstream * satinput);

queue<int> isoG1,isoG2;

int main(int argc, char* argv[])
{

  fstream file;
  string input_file;
  string test(argv[1]);
  int parse;
  //read input file name
  string temp_string = ".graphs";
  input_file = argv[1]+temp_string;
  file.open(input_file);
  int n1=0, n2=0, e1=0, e2=0; //n1 -> G; n2 -> G1; n1 < n2

  //find n1 and n2
  while(file)
  {
  	file>>parse;
  	if(parse != 0)
  	{
  	  e2++;
  	  if(parse>n2) n2 = parse;
  	}
  	else
  	{
  	  file>>parse;
  	  if(parse == 0) break;
  	}
  }
  e2 /= 2;
  while(file)
  {
  	file>>parse;
  	if(parse != 0)
  	{
  	  e1++;
  	  if(parse>n1) n1 = parse;
  	}
  }
  e1 /= 2;
  file.close();

  short isIsoG1[n1], isIsoG2[n2];
  int incomingG1[n1], outgoingG1[n1], incomingG2[n2], outgoingG2[n2];

  for(int i =0 ; i<n1; i++){
    isIsoG1[i] = 1;
    incomingG1[i] = 0;
    outgoingG1[i] = 0;
  }
  for(int i =0 ; i<n2; i++){
    isIsoG2[i] = 1;
    incomingG2[i] = 0;
    outgoingG2[i] = 0;
  }


  vector<vector<short>> E1(n1, vector<short>(n1)), E2(n2, vector<short>(n2));
  file.open(input_file);
  while(file)
  {
  	file >> parse;
  	if(parse != 0)
  	{
  	  int x = parse;
  	  file >> parse;
  	  E2[x-1][parse-1] = 1;

      isIsoG2[x-1] = 0;
      isIsoG2[parse-1] = 0;
      outgoingG2[x-1]++;
      incomingG2[parse-1]++;

  	}
  	else
  	{
  	  file >> parse;
  	  if (parse == 0)
  	  {
  		    break;
  	  }
  	  else
  	  {
  		    cout << "improper input file-E2" << endl;
  	  }
  	}
  }
  while(file)
  {
  	file >> parse;
  	int x = parse;
  	if(!file) break;
  	file >> parse;
  	if(parse != 0)
  	{
  	  E1[x-1][parse-1] = 1;

      isIsoG1[x-1] = 0;
      isIsoG1[parse-1] = 0;
  	  incomingG1[parse-1]++;
      outgoingG1[x-1]++;
    }
  }
  file.close();
	ofstream data(test+".data");
	data << n1 << " " << n2;
	data.close();

  for(int i =0; i<n1; i++){
    if(isIsoG1[i]==1)
      isoG1.push(i);
  }
  for(int i =0; i<n2; i++){
    if(isIsoG2[i]==1)
      isoG2.push(i);
  }

  temp_string = ".satinput";
  string output_file = argv[1]+temp_string;
  ofstream file1;
  file1.open(output_file);

  if(isoG1.size() > isoG2.size()){
    file1 << "p cnf " << "1" << " " << "1" << endl << "0\n";
    file1.close();
    return 0;
  }

  int num_var = n1*n2;
  int m1 = n1 - isoG1.size();
  int m2 = n2 - isoG2.size();
  long int num_clauses = isoG1.size() + m1 + (m1*m2*(m1+m2-2))/2 + (e1*(m2*m2 - e2 - m2)) + (e2*(m1*m1 - e1 - m1)) ;


  //file1 << "p cnf " << num_var << " " << num_clauses << endl;
  //cout << "p cnf " << num_var << " " << num_clauses << endl;

  //Mij = 0 -> i nd j cant be mapped; Mij = 1-> i and j can be mapped
  vector<vector<short>> M(n1, vector<short>(n2, 1));
  for(int i =0; i<n1; i++){
    for(int j = 0; j < n2; j++){
      if(incomingG1[i] > incomingG2[j] || outgoingG1[i] > outgoingG2[j])
        M[i][j] = 0;
    }
  }

  //write constraints to satinput file
  num_clauses = 0;
  num_clauses += isolatedMap(n1, n2, &file1);
  num_clauses += oneOneMap(n1, n2, &file1, &isIsoG1[0], &isIsoG2[0], M);
  num_clauses += edgeCondition(E1, E2, &file1, &isIsoG1[0], &isIsoG2[0], M);
  file1 << "p cnf " << num_var << " " << num_clauses << endl;

  file1.close();
  return 0;
}

int isolatedMap(int n1, int n2, ofstream * satinput){
  int count = 0;
  int x, y;
    while(!isoG1.empty()){
      x = isoG1.front();
      y = isoG2.front();
      isoG1.pop();
      isoG2.pop();
      for(int i=0; i<n2; i++)
      {
        if(i==y) *satinput << (x*n2 + i + 1) << " 0\n";
        else *satinput << -1*(x*n2 + i + 1) << " 0\n";
      }
      count+= n2;
    }
    //cout << count << endl;
    return count;
}

int oneOneMap(int n1, int n2, ofstream * satinput, short* isIsoG1, short* isIsoG2, vector<vector<short>> &M){
  int count = 0;
	// ofstream satinput;
	// satinput.open(test + ".satinput");

	//mij represented as i*n2 + j + 1 (where i and j starts from 0)
	//i in G is mapped to only one j in G'
	for(int i = 0; i<n1; i++){
    if(isIsoG1[i] == 1) continue;
		for(int j = 0; j < n2; j++){
      if(isIsoG2[j] == 1) continue;
      if(M[i][j] == 0){
        *satinput << -1*(i*n2 + j + 1) << " 0\n";
         count++;
      }
      else{
            for(int k = j+1; k < n2; k++){
                if(isIsoG2[k] == 1 || M[i][k] == 0) continue;
                *satinput << -1*(i*n2 + j + 1)<< " " << -1*(i*n2 + k + 1) << " 0\n";
                count++;
            }
      }
		}
    for(int j = 0 ; j < n2; j++){
      if(isIsoG2[j] == 1 || M[i][j] == 0) continue;
			*satinput << i*n2 + j + 1 << " ";
    }
    *satinput << "0\n";
    count++;
	}

	//j in G' is mapped to atmax one i in G
	for(int j = 0; j<n2; j++){
    if(isIsoG2[j] == 1) continue;
		for(int i = 0; i < n1; i++){
      if(isIsoG1[i] == 1 || M[i][j] == 0) continue;
			for(int k = i+1; k < n1; k++){
        if(isIsoG1[k] == 1 || M[k][j] == 0) continue;
				*satinput << -1*(i*n2 + j + 1) << " " << -1*(k*n2 + j + 1) << " 0\n";
        count++;
			}
		}
	}
  //cout << count << endl;
  return count;

	//satinput.close();
}

long int edgeCondition(vector<vector<short>> &e1, vector<vector<short>> &e2, ofstream * satinput, short * isIsoG1,
                    short * isIsoG2, vector<vector<short>> &M){
	// ofstream satinput;
	// satinput.open(test + ".satinput");
  long int count = 0;
	int n1 = e1.size(), n2 = e2.size();
	for(int i = 0; i < n1; i++){
    if(isIsoG1[i] == 1)continue;
		for(int j = 0; j < n1; j++){
      if(isIsoG1[j] == 1)continue;
			if(i == j) continue;
			for(int k = 0; k < n2; k++){
        if(isIsoG2[k] == 1 || M[i][k] == 0)continue;
				for(int l = 0; l < n2; l++){
          if(isIsoG2[l] == 1 || M[j][l] == 0)continue;
					if((k == l) || (e1[i][j] && e2[k][l]) || (!e1[i][j] && !e2[k][l])) continue;

					*satinput << -1*(i*n2+k + 1) << " " << -1*(j*n2 + l + 1) << " 0\n";
          count++;
				}
			}
		}
	}
  //cout << count << endl;
  return count;
}
