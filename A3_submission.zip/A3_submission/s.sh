./compile.sh
./run1.sh test
./minisat test.satinput test.satoutput
