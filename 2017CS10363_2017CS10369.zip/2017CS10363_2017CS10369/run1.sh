./step1 $1
