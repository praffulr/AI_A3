g++ -std=c++11 step1.cpp -o step1
g++ -std=c++11 step2.cpp -o step2
