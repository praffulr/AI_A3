./run2.sh test
python check.py test.graphs test.mapping
